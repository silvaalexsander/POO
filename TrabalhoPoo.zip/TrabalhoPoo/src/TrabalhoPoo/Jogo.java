package TrabalhoPoo;

import TrabalhoPoo.Personagens.Humano.Arqueiro;
import TrabalhoPoo.Personagens.Humano.Humano;
import TrabalhoPoo.Personagens.Humano.Robo;
import TrabalhoPoo.Personagens.Humano.Soldado;
import TrabalhoPoo.Personagens.Orc.Demonio;
import TrabalhoPoo.Personagens.Orc.Mago;
import TrabalhoPoo.Personagens.Orc.Ogro;
import TrabalhoPoo.Personagens.Orc.Orc;
import TrabalhoPoo.Personagens.Personagem;

import java.util.ArrayList;
import java.util.Random;

public class Jogo {
    public static void main(String[] args) {
        int aleatorio;
        int[]vetAleatorio = new int[100];

        Arqueiro arqueiro = new Arqueiro();
        arqueiro.setInteligencia(60);
        arqueiro.setVelocidade(60);
        arqueiro.setEquipamentos(20);
        //arqueiro.setVida(100);

        Soldado soldado = new Soldado();
        soldado.setInteligencia(20);
        soldado.setVelocidade(80);
        soldado.setEquipamentos(40);
        //soldado.setVida(100);

        Robo robo = new Robo();
        robo.setInteligencia(80);
        robo.setVelocidade(20);
        robo.setEquipamentos(60);
        //robo.setVida(100);

        Ogro ogro = new Ogro();
        ogro.setForca(60);
        ogro.setHabilidade(60);
        ogro.setAgilidade(20);
        //ogro.setVida(100);

        Mago mago = new Mago();
        mago.setForca(20);
        mago.setHabilidade(80);
        mago.setAgilidade(40);
        //mago.setVida(100);

        Demonio demonio = new Demonio();
        demonio.setForca(80);
        demonio.setHabilidade(20);
        demonio.setAgilidade(60);
        //demonio.setVida(100);

        ArrayList<Humano> humanos = new ArrayList<>();
        Random i = new Random();

        for(int j = 0; j < 100; j++){ //criando vetor de Humanos
            aleatorio = i.nextInt(3);
            if(aleatorio == 0){
                humanos.add(arqueiro);
            }
            else if(aleatorio == 1){
                humanos.add(soldado);
            }
            else{
                humanos.add(robo);
            }
        }

        ArrayList<Orc> orcs = new ArrayList<>();

        for(int count = 0; count < 100; count++){ //criando vetor de Orcs
            aleatorio = i.nextInt(3);
            if(aleatorio == 0){
                orcs.add(mago);
            }
            else if(aleatorio == 1){
                orcs.add(demonio);
            }
            else{
                orcs.add(ogro);
            }
        }
/*
        for(int k = 0; k < 3; k++){
            System.out.println("---------------------------->ITERACAO " + (k+1) + "<-----------------------------");
            System.out.println(humanos.get(k));
            humanos.get(k).perdeVida(orcs.get(k).getAgilidade() - humanos.get(k).getVelocidade());
            System.out.println(humanos.get(k));
            System.out.println(orcs.get(k));
            orcs.get(k).ganhaVida(humanos.get(k).getVelocidade() - orcs.get(k).getForca());
            System.out.println(orcs.get(k));
        }*/
        for(int c = 0; c < 5; c++){
            if(c == 1){
                humanos.get(c).ganhaVida(20);
            }
            System.out.println(humanos.get(c));
        }



         /*for(int k = 0; k < humanos.size(); k++){
            if(vetAleatorio[k] == 0){
                System.out.println("Modalidae: Força VS Inteligência");
            }
            else if(vetAleatorio[k] == 1){
                System.out.println("Modalidade: Velocidade VS Habilidade");
            }
            else if(vetAleatorio[k] == 2){
                System.out.println("Modalidade: Equipamentos VS Agilidade");
            }
            System.out.println(humanos.get(k));
            System.out.println(orcs.get(k));

          */


        }
        /*ogro.perdeVida(arqueiro.getInteligencia());
        ogro.ganhaVida(soldado.getEquipamentos());
        System.out.println(ogro);*/

    }

