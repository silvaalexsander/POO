package TrabalhoPoo.Personagens.Orc;

public class Mago extends Orc{

    private String nome = "Mago";

    @Override
    public void ataque() {

    }

    @Override
    public void defesa() {

    }

    @Override
    public String toString() {
        return nome + "\nForca " + getForca() + "\nAgilidade " + getAgilidade() + "\nHabilidade " + getHabilidade() + " " +
                "\nVida " + getVida() + "\n";
    }
}
