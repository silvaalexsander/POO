package TrabalhoPoo.Personagens;

public abstract class Personagem {
    private int vida = 100;


    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int ganhaVida(int vida){
        this.vida = this.vida + vida;

        return vida;
    }

    public int perdeVida(int vida){
        this.vida = this.vida - vida;

        return vida;
    }

    public abstract void ataque();
    public abstract void defesa();

    public abstract String toString();
}
