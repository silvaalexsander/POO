package TrabalhoPoo.Personagens.Orc;

import TrabalhoPoo.Personagens.Personagem;

public abstract class Orc extends Personagem {

     private int forca;
     private int habilidade;
     private int agilidade;


     public int getForca() {
          return forca;
     }

     public void setForca(int forca) {
          this.forca = forca;
     }

     public int getHabilidade() {
          return habilidade;
     }

     public void setHabilidade(int habilidade) {
          this.habilidade = habilidade;
     }

     public int getAgilidade() {
          return agilidade;
     }

     public void setAgilidade(int agilidade) {
          this.agilidade = agilidade;
     }
}
