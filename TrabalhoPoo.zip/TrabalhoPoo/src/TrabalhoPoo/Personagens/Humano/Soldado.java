package TrabalhoPoo.Personagens.Humano;

public class Soldado extends Humano{

    private String nome = "Soldado";

    @Override
    public void ataque() {

    }

    @Override
    public void defesa() {

    }



    @Override
    public String toString() {
        return nome + "\nInteligencia " + getInteligencia() + "\nVelocidade " + getVelocidade() + "\nEquipamento " + getEquipamentos() + " " +
                "\nVida " + getVida() + "\n";
    }
}
