package TrabalhoPoo.Personagens.Orc;

public class Ogro extends Orc{

    private String nome = "Ogro";

    @Override
    public void ataque() {

    }

    @Override
    public void defesa() {

    }

    @Override
    public String toString() {
        return nome + "\nForca " + getForca() + "\nAgilidade " + getAgilidade() + "\nHabilidade " + getHabilidade() + " " +
                "\nVida " + getVida() + "\n";
    }
}
