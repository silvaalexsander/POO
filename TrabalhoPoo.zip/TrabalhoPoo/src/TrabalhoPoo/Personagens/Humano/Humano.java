package TrabalhoPoo.Personagens.Humano;

import TrabalhoPoo.Personagens.Personagem;

public abstract class Humano extends Personagem {

    private int inteligencia;
    private int velocidade;
    private int equipamentos;



    public int getInteligencia() {
        return inteligencia;
    }

    public void setInteligencia(int inteligencia) {
        this.inteligencia = inteligencia;
    }

    public int getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }

    public int getEquipamentos() {
        return equipamentos;
    }

    public void setEquipamentos(int equipamentos) {
        this.equipamentos = equipamentos;
    }


}
