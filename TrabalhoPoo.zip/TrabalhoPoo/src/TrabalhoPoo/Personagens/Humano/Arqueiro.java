package TrabalhoPoo.Personagens.Humano;

public class Arqueiro extends Humano {

    private String nome = "Arqueiro";

    @Override
    public void ataque() {
        System.out.println("Flechada na cabeca");
        
    }

    @Override
    public void defesa() {

    }

    @Override
    public String toString() {
        return nome + "\nInteligencia " + getInteligencia() + "\nVelocidade " + getVelocidade() + "\nEquipamento " + getEquipamentos() + " " +
                "\nVida " + getVida() + "\n";
    }

}
